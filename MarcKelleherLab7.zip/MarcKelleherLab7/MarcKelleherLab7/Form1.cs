﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MarcKelleherLab7
{
    public partial class wordProcessingForm : Form
    {
        public wordProcessingForm()
        {
            InitializeComponent();
        }
        const int noOfDates = 100;
        string[] dateTimeArray = new string[noOfDates];
        private void wordProcessingForm_Load(object sender, EventArgs e)
        {
            //Assigns ImageList images to the ToolStrip buttons:
            imageListLoader();
            
            //Initiates the date/time status label for the form:
            dateTimeStatusLabel.Text = DateTime.Now.ToString();
        }

        private void cutButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Cuts text to the clipboard:
                Clipboard.SetText(myRichTextBox.SelectedText);
                myRichTextBox.SelectedText = String.Empty;
            }
            catch
            {
                //Error is text won't cut:
                MessageBox.Show("You must select something to cut.");
            }
        }

        private void pasteButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Pastes text from the clipboard:
                string cutText = Clipboard.GetText();
                myRichTextBox.Text = myRichTextBox.Text.Insert(myRichTextBox.SelectionStart, cutText);
            }
            catch
            {
                //Error if text won't paste:
                MessageBox.Show("You must select something to paste.");
            }
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //Changes text color and font:
                switch (colorFontComboBox.SelectedIndex)
                {
                    case 0:
                        generalFormColorDialog.ShowDialog();
                        myRichTextBox.SelectionColor = generalFormColorDialog.Color;
                        break;
                    case 1:
                        generalFormFontDialog.ShowDialog();
                        myRichTextBox.SelectionFont = generalFormFontDialog.Font;
                        break;
                    case 2:
                        myRichTextBox.SelectionColor = Color.Empty;
                        myRichTextBox.SelectionFont = DefaultFont;
                        break;
                }
            }
            catch
            {
                //Error if form color won't change:
                MessageBox.Show("Please try a different color or function.");
            }
        }

        private void openNotepadButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Attempt to run the Notepad program:
                if(otherProgramStatusLabel.Text != "Notepad was opened")
                {
                    this.formTimer.Start();
                    notepadProcess.EnableRaisingEvents = true;
                    notepadProcess.Start();
                    otherProgramStatusLabel.Text = "Notepad was opened";
                }
                else
                {
                    //Message if program is already open:
                    MessageBox.Show("Notepad is open");
                }
            }
            catch
            {
                //Message if the program doesn't run:
                MessageBox.Show("Notepad is already running or doesn't exist");
            }
        }

        private void closeNotepadButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Attempt to kill the Notepad program:
                notepadProcess.Kill();
                MessageBox.Show("Notepad was terminated");
                otherProgramStatusLabel.Text = "Notepad was closed";
            }
            catch
            {
                //Message if the program doesn't quit:
                MessageBox.Show("Notepad is not running.");
            }
        }

        private void openChromeButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Attempt to run the Chrome program:
                if (otherProgramStatusLabel.Text != "Chrome was opened")
                {
                    //Starts the program:
                    chromeProcess.EnableRaisingEvents = true;
                    chromeProcess.Start();
                    otherProgramStatusLabel.Text = "Chrome was opened";
                }
                else
                {
                    //Message if program is already open:
                    MessageBox.Show("Chrome is open");
                }
            }
            catch
            {
                //Message if the program doesn't run:
                MessageBox.Show("Chrome is already running or doesn't exist");
            }
                
        }

        private void closeChromeButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Attempt to kill the Chrome program:
                chromeProcess.Kill();
                otherProgramStatusLabel.Text = "Chrome was closed";
            }
            catch
            {
                //Message if the program doesn't quit:
                MessageBox.Show("Chrome is not running or will not close");
            }
        }

        private void wordProcessingForm_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                //Changes the form size:
                if (this.WindowState == FormWindowState.Maximized)
                {
                    //Makes form size smaller:
                    myNotifyIcon.Icon = SystemIcons.Warning;
                    myNotifyIcon.Visible = true;
                    myNotifyIcon.BalloonTipText = "Your form size changed";
                    myNotifyIcon.ShowBalloonTip(1000);
                }
                else
                {
                    //Puts form back to normal size:
                    myNotifyIcon.BalloonTipText = "Your form is back to normal size";
                    myNotifyIcon.ShowBalloonTip(1000);
                }
            }
            catch
            {
                //Error message if form size won't change:
                MessageBox.Show("Unable to change text size.");
            }
        }

        private void formTimer_Tick(object sender, EventArgs e)
        {
            //Starts form timer:
            toolStripProgressBar.Visible = true;
            toolStripProgressBar.Increment(1);
        }

        private void exitToolStripButton_Click(object sender, EventArgs e)
        {
            //Attempts to close the program:
            this.Close();
        }

        private void toolStripComboBox_Click(object sender, EventArgs e)
        {
        }

        private void copyToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Copies text to clipboard:
                Clipboard.SetText(myRichTextBox.SelectedText);
            }
            catch
            {
                //Displays error message:
                MessageBox.Show("You must select something to copy.");
            }
            
        }

        private void leftTextToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Aligns the text to the left side:
                myRichTextBox.SelectionAlignment = HorizontalAlignment.Left;
            }
            catch
            {
                //Displays error message:
                MessageBox.Show("Unable to justify text.");
            }
        }

        private void centerTextToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Aligns the text to the center:
                myRichTextBox.SelectionAlignment = HorizontalAlignment.Center;
            }
            catch
            {
                //Displays error message:
                MessageBox.Show("Unable to justify text.");
            }
        }

        private void rightTextToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Aligns the text to the right side:
                myRichTextBox.SelectionAlignment = HorizontalAlignment.Right;
            }
            catch
            {
                //Displays error message:
                MessageBox.Show("Unable to justify text.");
            }
         }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            int index = (dateTimeComboBox.Items.Count);
            bool duplicate;
            //Add new calendar item to availability comboBox and array:
            try
            {
                //Check for duplicates:
                duplicate = false;
                foreach (var listedDateTime in dateTimeComboBox.Items)
                {
                    if (formDateTimePicker.Value.ToString() == listedDateTime.ToString())
                    {
                        //Sets duplicate values to indicate that it is a dupicate:
                        duplicate = true;
                    }
                }
                if (duplicate == false)
                {
                    //Adds item to combo box and array if not a duplicate:
                    dateTimeArray[index] = formDateTimePicker.Value.ToString();
                    dateTimeComboBox.Items.Add(formDateTimePicker.Value);
                }
            }
            catch
            {
                //Error message in case the method has an exception:
                MessageBox.Show("Item cannot be added to list.");
            }
        }

        private void saveFileToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Saves the file when chosen:
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.DefaultExt = "rtf";
                if (saveFile.ShowDialog() == DialogResult.OK)
                {
                    //Saves the rich text file:
                    myRichTextBox.SaveFile(saveFile.FileName, RichTextBoxStreamType.RichText);
                }
            }
            catch
            {
                //Error message if unable to save file:
                MessageBox.Show("No text to save or unable to save file");
            }
        }

        private void openFileToolStripButton_Click(object sender, EventArgs e)
        {
            //Clears the textbox before opening a file:
            myRichTextBox.Clear();
            //Opens file and displays the content in the textbox:
            try
            {
                //Opens dialog box to search for file to open:
                Stream mystream;
                OpenFileDialog openFileDialog1 = new OpenFileDialog();
                openFileDialog1.DefaultExt = "rtf";
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {

                    if ((mystream = openFileDialog1.OpenFile()) != null)
                    {
                        //Loads the file as Rich Text:
                        myRichTextBox.LoadFile(openFileDialog1.FileName, RichTextBoxStreamType.RichText);
                    }
                }
            }
            //Error message if the file won't load:
            catch
            {
                MessageBox.Show("The file was too big or not a text file");
            }
        }

        private void myAvailabilityListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void addToArrayButton_Click(object sender, EventArgs e)
        {
            //Declare Boolean variables to catch the duplicates:
            bool duplicate;
            bool duplicate2;
            //Display the array's content in the ListBox:
            try
            {
                duplicate2 = false;
                foreach (var dateTime in dateTimeArray)
                {
                    //For each item present in the array:
                    if (dateTime != null)
                    {
                        duplicate = false;
                        foreach (var listedDateTime in myAvailabilityListBox.Items)
                        {
                            if (dateTime == listedDateTime.ToString())
                            {
                                //Sets duplicate values to indicate that dupicates exist:
                                duplicate = true;
                                duplicate2 = true;
                            }
                        }
                        if (duplicate == false)
                        {
                            //Adds item to list box if not a duplicate:
                            myAvailabilityListBox.Items.Add(dateTime);
                        }
                    }
                }
                if (duplicate2 == true)
                {
                    //Lets user know that the duplicates exist but weren't added:
                    MessageBox.Show("Duplicates were found and not added");
                }
            }    
            catch
            {
                //Error message in case the method has an exception:
                MessageBox.Show("Item cannot be added to list.");
            }
        }

        private void dateTimeComboBox_Click(object sender, EventArgs e)
        {
        }

        private void statusStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void wordProcessingForm_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            try
            {
                if(FormClose())
                {
                    // Cancel the Closing event from closing the form:
                    e.Cancel = true;
                    // Call method to save file:
                    saveFileToolStripButton.PerformClick();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Unable to save");
                this.Close();
            }
        }

        private void generalFormToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void imageListLoader()
        {
            //Assigns ImageList images to the ToolStrip buttons:
            generalFormToolStrip.ImageList = generalFormImageList;
            exitToolStripButton.ImageIndex = 0;
            saveFileToolStripButton.ImageIndex = 1;
            openFileToolStripButton.ImageIndex = 2;
            cutToolStripButton.ImageIndex = 3;
            copyToolStripButton.ImageIndex = 4;
            pasteToolStripButton.ImageIndex = 5;
            leftTextToolStripButton.ImageIndex = 6;
            centerTextToolStripButton.ImageIndex = 7;
            rightTextToolStripButton.ImageIndex = 8;
        }

        private bool FormClose()
        {
            if (MessageBox.Show("Unsaved file.  Do you want to save?", "Work Not Saved",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
