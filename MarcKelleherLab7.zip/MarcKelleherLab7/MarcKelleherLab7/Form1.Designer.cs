﻿namespace MarcKelleherLab7
{
    partial class wordProcessingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(wordProcessingForm));
            this.generalFormImageList = new System.Windows.Forms.ImageList(this.components);
            this.generalFormToolStrip = new System.Windows.Forms.ToolStrip();
            this.exitToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveFileToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.openFileToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cutToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.copyToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.leftTextToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.centerTextToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.rightTextToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.colorFontComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.dateTimeComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.myRichTextBox = new System.Windows.Forms.RichTextBox();
            this.generalFormColorDialog = new System.Windows.Forms.ColorDialog();
            this.callOtherProgramsGroupBox = new System.Windows.Forms.GroupBox();
            this.closeChromeButton = new System.Windows.Forms.Button();
            this.openChromeButton = new System.Windows.Forms.Button();
            this.closeNotepadButton = new System.Windows.Forms.Button();
            this.openNotepadButton = new System.Windows.Forms.Button();
            this.notepadProcess = new System.Diagnostics.Process();
            this.chromeProcess = new System.Diagnostics.Process();
            this.myNotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.formTimer = new System.Windows.Forms.Timer(this.components);
            this.generalFormToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.formDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.myAvailabilityLabel = new System.Windows.Forms.Label();
            this.myAvailabilityListBox = new System.Windows.Forms.ListBox();
            this.addToArrayButton = new System.Windows.Forms.Button();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.otherProgramStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.dateTimeStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.generalFormFontDialog = new System.Windows.Forms.FontDialog();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.generalFormToolStrip.SuspendLayout();
            this.callOtherProgramsGroupBox.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // generalFormImageList
            // 
            this.generalFormImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("generalFormImageList.ImageStream")));
            this.generalFormImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.generalFormImageList.Images.SetKeyName(0, "X.jpg");
            this.generalFormImageList.Images.SetKeyName(1, "Disk.jpg");
            this.generalFormImageList.Images.SetKeyName(2, "Folder.png");
            this.generalFormImageList.Images.SetKeyName(3, "Scissors.png");
            this.generalFormImageList.Images.SetKeyName(4, "Folder Copy.jpg");
            this.generalFormImageList.Images.SetKeyName(5, "Clipboard.png");
            this.generalFormImageList.Images.SetKeyName(6, "Left justified text.jpg");
            this.generalFormImageList.Images.SetKeyName(7, "Center text.jpg");
            this.generalFormImageList.Images.SetKeyName(8, "Right justified text.png");
            // 
            // generalFormToolStrip
            // 
            this.generalFormToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripButton,
            this.saveFileToolStripButton,
            this.openFileToolStripButton,
            this.cutToolStripButton,
            this.copyToolStripButton,
            this.pasteToolStripButton,
            this.leftTextToolStripButton,
            this.centerTextToolStripButton,
            this.rightTextToolStripButton,
            this.colorFontComboBox,
            this.dateTimeComboBox});
            this.generalFormToolStrip.Location = new System.Drawing.Point(0, 0);
            this.generalFormToolStrip.Name = "generalFormToolStrip";
            this.generalFormToolStrip.Size = new System.Drawing.Size(1011, 25);
            this.generalFormToolStrip.TabIndex = 0;
            this.generalFormToolStrip.Text = "toolStrip1";
            this.generalFormToolStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.generalFormToolStrip_ItemClicked);
            // 
            // exitToolStripButton
            // 
            this.exitToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.exitToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripButton.Image")));
            this.exitToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.exitToolStripButton.Name = "exitToolStripButton";
            this.exitToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.exitToolStripButton.ToolTipText = "Exit";
            this.exitToolStripButton.Click += new System.EventHandler(this.exitToolStripButton_Click);
            // 
            // saveFileToolStripButton
            // 
            this.saveFileToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveFileToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("saveFileToolStripButton.Image")));
            this.saveFileToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveFileToolStripButton.Name = "saveFileToolStripButton";
            this.saveFileToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.saveFileToolStripButton.ToolTipText = "Save";
            this.saveFileToolStripButton.Click += new System.EventHandler(this.saveFileToolStripButton_Click);
            // 
            // openFileToolStripButton
            // 
            this.openFileToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openFileToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("openFileToolStripButton.Image")));
            this.openFileToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openFileToolStripButton.Name = "openFileToolStripButton";
            this.openFileToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.openFileToolStripButton.ToolTipText = "Open";
            this.openFileToolStripButton.Click += new System.EventHandler(this.openFileToolStripButton_Click);
            // 
            // cutToolStripButton
            // 
            this.cutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cutToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripButton.Image")));
            this.cutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutToolStripButton.Name = "cutToolStripButton";
            this.cutToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.cutToolStripButton.ToolTipText = "Cut";
            this.cutToolStripButton.Click += new System.EventHandler(this.cutButton_Click);
            // 
            // copyToolStripButton
            // 
            this.copyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.copyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripButton.Image")));
            this.copyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copyToolStripButton.Name = "copyToolStripButton";
            this.copyToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.copyToolStripButton.ToolTipText = "Copy";
            this.copyToolStripButton.Click += new System.EventHandler(this.copyToolStripButton_Click);
            // 
            // pasteToolStripButton
            // 
            this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pasteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripButton.Image")));
            this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pasteToolStripButton.Name = "pasteToolStripButton";
            this.pasteToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.pasteToolStripButton.ToolTipText = "Paste";
            this.pasteToolStripButton.Click += new System.EventHandler(this.pasteButton_Click);
            // 
            // leftTextToolStripButton
            // 
            this.leftTextToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.leftTextToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("leftTextToolStripButton.Image")));
            this.leftTextToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.leftTextToolStripButton.Name = "leftTextToolStripButton";
            this.leftTextToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.leftTextToolStripButton.ToolTipText = "Left Text";
            this.leftTextToolStripButton.Click += new System.EventHandler(this.leftTextToolStripButton_Click);
            // 
            // centerTextToolStripButton
            // 
            this.centerTextToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.centerTextToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("centerTextToolStripButton.Image")));
            this.centerTextToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.centerTextToolStripButton.Name = "centerTextToolStripButton";
            this.centerTextToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.centerTextToolStripButton.ToolTipText = "Center Text";
            this.centerTextToolStripButton.Click += new System.EventHandler(this.centerTextToolStripButton_Click);
            // 
            // rightTextToolStripButton
            // 
            this.rightTextToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.rightTextToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("rightTextToolStripButton.Image")));
            this.rightTextToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.rightTextToolStripButton.Name = "rightTextToolStripButton";
            this.rightTextToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.rightTextToolStripButton.ToolTipText = "Right Text";
            this.rightTextToolStripButton.Click += new System.EventHandler(this.rightTextToolStripButton_Click);
            // 
            // colorFontComboBox
            // 
            this.colorFontComboBox.Items.AddRange(new object[] {
            "Color",
            "Font",
            "Reset"});
            this.colorFontComboBox.Name = "colorFontComboBox";
            this.colorFontComboBox.Size = new System.Drawing.Size(121, 25);
            this.colorFontComboBox.Text = "Select One";
            this.colorFontComboBox.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox1_SelectedIndexChanged);
            this.colorFontComboBox.Click += new System.EventHandler(this.toolStripComboBox_Click);
            // 
            // dateTimeComboBox
            // 
            this.dateTimeComboBox.AutoSize = false;
            this.dateTimeComboBox.DropDownWidth = 230;
            this.dateTimeComboBox.MaxDropDownItems = 20;
            this.dateTimeComboBox.Name = "dateTimeComboBox";
            this.dateTimeComboBox.Size = new System.Drawing.Size(230, 23);
            this.dateTimeComboBox.Text = "I am available on the following dates:";
            this.dateTimeComboBox.ToolTipText = "Availability";
            this.dateTimeComboBox.Click += new System.EventHandler(this.dateTimeComboBox_Click);
            // 
            // myRichTextBox
            // 
            this.myRichTextBox.Location = new System.Drawing.Point(38, 65);
            this.myRichTextBox.Name = "myRichTextBox";
            this.myRichTextBox.Size = new System.Drawing.Size(470, 458);
            this.myRichTextBox.TabIndex = 1;
            this.myRichTextBox.Text = "";
            // 
            // callOtherProgramsGroupBox
            // 
            this.callOtherProgramsGroupBox.Controls.Add(this.closeChromeButton);
            this.callOtherProgramsGroupBox.Controls.Add(this.openChromeButton);
            this.callOtherProgramsGroupBox.Controls.Add(this.closeNotepadButton);
            this.callOtherProgramsGroupBox.Controls.Add(this.openNotepadButton);
            this.callOtherProgramsGroupBox.Location = new System.Drawing.Point(584, 307);
            this.callOtherProgramsGroupBox.Name = "callOtherProgramsGroupBox";
            this.callOtherProgramsGroupBox.Size = new System.Drawing.Size(324, 186);
            this.callOtherProgramsGroupBox.TabIndex = 2;
            this.callOtherProgramsGroupBox.TabStop = false;
            this.callOtherProgramsGroupBox.Text = "Call Other Programs";
            // 
            // closeChromeButton
            // 
            this.closeChromeButton.Location = new System.Drawing.Point(169, 119);
            this.closeChromeButton.Name = "closeChromeButton";
            this.closeChromeButton.Size = new System.Drawing.Size(101, 30);
            this.closeChromeButton.TabIndex = 3;
            this.closeChromeButton.Text = "Close Chrome";
            this.closeChromeButton.UseVisualStyleBackColor = true;
            this.closeChromeButton.Click += new System.EventHandler(this.closeChromeButton_Click);
            // 
            // openChromeButton
            // 
            this.openChromeButton.Location = new System.Drawing.Point(32, 119);
            this.openChromeButton.Name = "openChromeButton";
            this.openChromeButton.Size = new System.Drawing.Size(97, 30);
            this.openChromeButton.TabIndex = 2;
            this.openChromeButton.Text = "Open Chrome";
            this.openChromeButton.UseVisualStyleBackColor = true;
            this.openChromeButton.Click += new System.EventHandler(this.openChromeButton_Click);
            // 
            // closeNotepadButton
            // 
            this.closeNotepadButton.Location = new System.Drawing.Point(169, 55);
            this.closeNotepadButton.Name = "closeNotepadButton";
            this.closeNotepadButton.Size = new System.Drawing.Size(101, 30);
            this.closeNotepadButton.TabIndex = 1;
            this.closeNotepadButton.Text = "Close Notepad";
            this.closeNotepadButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.closeNotepadButton.UseVisualStyleBackColor = true;
            this.closeNotepadButton.Click += new System.EventHandler(this.closeNotepadButton_Click);
            // 
            // openNotepadButton
            // 
            this.openNotepadButton.Location = new System.Drawing.Point(32, 54);
            this.openNotepadButton.Name = "openNotepadButton";
            this.openNotepadButton.Size = new System.Drawing.Size(97, 30);
            this.openNotepadButton.TabIndex = 0;
            this.openNotepadButton.Text = "Open Notepad";
            this.openNotepadButton.UseVisualStyleBackColor = true;
            this.openNotepadButton.Click += new System.EventHandler(this.openNotepadButton_Click);
            // 
            // notepadProcess
            // 
            this.notepadProcess.StartInfo.Domain = "";
            this.notepadProcess.StartInfo.FileName = "notepad.exe";
            this.notepadProcess.StartInfo.LoadUserProfile = false;
            this.notepadProcess.StartInfo.Password = null;
            this.notepadProcess.StartInfo.StandardErrorEncoding = null;
            this.notepadProcess.StartInfo.StandardOutputEncoding = null;
            this.notepadProcess.StartInfo.UserName = "";
            this.notepadProcess.SynchronizingObject = this;
            // 
            // chromeProcess
            // 
            this.chromeProcess.StartInfo.Domain = "";
            this.chromeProcess.StartInfo.FileName = "chrome.exe";
            this.chromeProcess.StartInfo.LoadUserProfile = false;
            this.chromeProcess.StartInfo.Password = null;
            this.chromeProcess.StartInfo.StandardErrorEncoding = null;
            this.chromeProcess.StartInfo.StandardOutputEncoding = null;
            this.chromeProcess.StartInfo.UserName = "";
            this.chromeProcess.SynchronizingObject = this;
            // 
            // myNotifyIcon
            // 
            this.myNotifyIcon.Text = "notifyIcon1";
            this.myNotifyIcon.Visible = true;
            // 
            // formTimer
            // 
            this.formTimer.Interval = 10;
            this.formTimer.Tick += new System.EventHandler(this.formTimer_Tick);
            // 
            // formDateTimePicker
            // 
            this.formDateTimePicker.Location = new System.Drawing.Point(587, 4);
            this.formDateTimePicker.Name = "formDateTimePicker";
            this.formDateTimePicker.Size = new System.Drawing.Size(267, 20);
            this.formDateTimePicker.TabIndex = 3;
            this.formDateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // myAvailabilityLabel
            // 
            this.myAvailabilityLabel.AutoSize = true;
            this.myAvailabilityLabel.Location = new System.Drawing.Point(701, 70);
            this.myAvailabilityLabel.Name = "myAvailabilityLabel";
            this.myAvailabilityLabel.Size = new System.Drawing.Size(73, 13);
            this.myAvailabilityLabel.TabIndex = 4;
            this.myAvailabilityLabel.Text = "My Availability";
            this.myAvailabilityLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // myAvailabilityListBox
            // 
            this.myAvailabilityListBox.FormattingEnabled = true;
            this.myAvailabilityListBox.Location = new System.Drawing.Point(584, 97);
            this.myAvailabilityListBox.Name = "myAvailabilityListBox";
            this.myAvailabilityListBox.Size = new System.Drawing.Size(321, 121);
            this.myAvailabilityListBox.TabIndex = 5;
            this.myAvailabilityListBox.SelectedIndexChanged += new System.EventHandler(this.myAvailabilityListBox_SelectedIndexChanged);
            // 
            // addToArrayButton
            // 
            this.addToArrayButton.Location = new System.Drawing.Point(671, 242);
            this.addToArrayButton.Name = "addToArrayButton";
            this.addToArrayButton.Size = new System.Drawing.Size(136, 34);
            this.addToArrayButton.TabIndex = 6;
            this.addToArrayButton.Text = "Add Schedule to Array";
            this.addToArrayButton.UseVisualStyleBackColor = true;
            this.addToArrayButton.Click += new System.EventHandler(this.addToArrayButton_Click);
            // 
            // statusStrip2
            // 
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.otherProgramStatusLabel,
            this.toolStripProgressBar,
            this.dateTimeStatusLabel});
            this.statusStrip2.Location = new System.Drawing.Point(0, 552);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(1011, 22);
            this.statusStrip2.TabIndex = 7;
            this.statusStrip2.Text = "statusStrip2";
            this.statusStrip2.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip2_ItemClicked);
            // 
            // otherProgramStatusLabel
            // 
            this.otherProgramStatusLabel.Name = "otherProgramStatusLabel";
            this.otherProgramStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // dateTimeStatusLabel
            // 
            this.dateTimeStatusLabel.Name = "dateTimeStatusLabel";
            this.dateTimeStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar.Visible = false;
            // 
            // wordProcessingForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 574);
            this.Controls.Add(this.statusStrip2);
            this.Controls.Add(this.addToArrayButton);
            this.Controls.Add(this.myAvailabilityListBox);
            this.Controls.Add(this.myAvailabilityLabel);
            this.Controls.Add(this.formDateTimePicker);
            this.Controls.Add(this.callOtherProgramsGroupBox);
            this.Controls.Add(this.myRichTextBox);
            this.Controls.Add(this.generalFormToolStrip);
            this.Name = "wordProcessingForm";
            this.Text = "Word Processing";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.wordProcessingForm_FormClosing_1);
            this.Load += new System.EventHandler(this.wordProcessingForm_Load);
            this.SizeChanged += new System.EventHandler(this.wordProcessingForm_SizeChanged);
            this.generalFormToolStrip.ResumeLayout(false);
            this.generalFormToolStrip.PerformLayout();
            this.callOtherProgramsGroupBox.ResumeLayout(false);
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList generalFormImageList;
        private System.Windows.Forms.ToolStrip generalFormToolStrip;
        private System.Windows.Forms.ToolStripButton cutToolStripButton;
        private System.Windows.Forms.ToolStripButton pasteToolStripButton;
        private System.Windows.Forms.ToolStripButton copyToolStripButton;
        private System.Windows.Forms.ToolStripComboBox colorFontComboBox;
        private System.Windows.Forms.RichTextBox myRichTextBox;
        private System.Windows.Forms.ColorDialog generalFormColorDialog;
        private System.Windows.Forms.GroupBox callOtherProgramsGroupBox;
        private System.Windows.Forms.Button closeChromeButton;
        private System.Windows.Forms.Button openChromeButton;
        private System.Windows.Forms.Button closeNotepadButton;
        private System.Windows.Forms.Button openNotepadButton;
        private System.Diagnostics.Process notepadProcess;
        private System.Diagnostics.Process chromeProcess;
        private System.Windows.Forms.NotifyIcon myNotifyIcon;
        private System.Windows.Forms.Timer formTimer;
        private System.Windows.Forms.ToolStripButton exitToolStripButton;
        private System.Windows.Forms.ToolStripButton saveFileToolStripButton;
        private System.Windows.Forms.ToolStripButton openFileToolStripButton;
        private System.Windows.Forms.ToolStripButton centerTextToolStripButton;
        private System.Windows.Forms.ToolStripButton rightTextToolStripButton;
        private System.Windows.Forms.ToolStripButton leftTextToolStripButton;
        private System.Windows.Forms.ToolTip generalFormToolTip;
        private System.Windows.Forms.DateTimePicker formDateTimePicker;
        private System.Windows.Forms.ListBox myAvailabilityListBox;
        private System.Windows.Forms.Label myAvailabilityLabel;
        private System.Windows.Forms.Button addToArrayButton;
        private System.Windows.Forms.ToolStripComboBox dateTimeComboBox;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripStatusLabel dateTimeStatusLabel;
        private System.Windows.Forms.FontDialog generalFormFontDialog;
        private System.Windows.Forms.ToolStripStatusLabel otherProgramStatusLabel;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
    }
}

